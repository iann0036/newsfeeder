<?php
/**
 * @KingSize 2011
 **/
?>
<?php get_header(); ?>

<!-- GOOGLE ANALYTICS -->
<?php include (TEMPLATEPATH . "/lib/google-analytics-input.php"); ?>
<!-- GOOGLE ANALYTICS -->

<script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/background_slider.js"></script>		