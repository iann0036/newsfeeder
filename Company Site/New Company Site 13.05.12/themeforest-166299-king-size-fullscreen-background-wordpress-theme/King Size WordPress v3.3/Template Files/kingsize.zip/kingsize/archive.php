<?php $tpl_body_id = 'blog_overview'; get_header(); ?>

<?php get_template_part( 'loop' ); ?>
					
<?php get_footer(); ?>